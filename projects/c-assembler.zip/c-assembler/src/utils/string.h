#ifndef String
#define String char*
#endif
