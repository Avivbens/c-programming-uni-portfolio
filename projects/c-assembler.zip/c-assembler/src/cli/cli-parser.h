#include "../utils/string.h"

#define FILE_EXTENSION ".as"
#define MAX_PATH_LENGTH 128

String *get_files_names(int argc, String *argv);
