#include "../utils/string.h"

int is_file_exists(String file_path);
