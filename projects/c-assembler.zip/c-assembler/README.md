# `C Assembler`

[![Trello Board](https://img.shields.io/badge/Trello-Main_Board-026AA7?logo=trello)](https://trello.com/b/LkRTtcwC/trello-agile-sprint-board-template)

### Run with arguments

```bash
nx run c-assembler:run --args="--input projects/c-assembler/assets/file1"
```
